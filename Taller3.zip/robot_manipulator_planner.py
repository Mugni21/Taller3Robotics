#!/usr/bin/env python3

import rospy
import numpy as np

from std_msgs.msg import String

current_msg = ""
position_msg = ""
x = 0
y = 0

dt = 0.1 #10Hz

# setup ros publisher
pub = rospy.Publisher('robot_manipulator_teleop', String, queue_size=10) # name of topic: /trutlebot


def callback(vel_msg):
    global current_msg
    global position_msg
    global mag
    global ang

    #print("el mensaje es"+current_msg)
    x_current = float(str(vel_msg.data).split(":")[0])
    y_current = float(str(vel_msg.data).split(":")[1])
    
    
    mag = np.sqrt(x_current^2 + y_current^2)
    ang = np.arctan2(y/x)
    
    #Se define el numero de comandos a enviar
    distancia_clicks = mag/(0.02) #Constantes para realizar la conversion
    ang_clicks = ang/1.73 #Constante para realizar la conversion
    
    
    for i in distancia_clicks:
        pub.publish("T")
    for i in ang_clicks:
        if ang <= 0: 
            pub.publish("F")
        else: 
            pub.publish("R")    
    
  
def listener():
    
    
    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('planner', anonymous=True)

    rospy.Subscriber("Posicion_goal", String, callback)
    
    # setup ros publisher
    #pub = rospy.Publisher('Flash_bot_position', String, queue_size=10) # name of topic: /trutlebot

    #rate = rospy.Rate(10) # publish messages at 10Hz
    
    # spin() simply keeps python from exiting until this node is stopped
    
    
    
    #rospy.loginfo(str(x)+", "+str(y))
    #pub.publish(position_msg)
    rospy.spin()
        

if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
