#####COMO CORRER CADA NODO#####
Preliminares: 

Siempre tener roscore corriendo en el fondo antes de hacer cualquier cosa.
Correr coppelia sim y darle play a la simulación antes de correr cualquier nodo.





Nodo turtle_bot_teleop.py: 

Para correr este nodo, simplemente debe dirigirse al workspace del proyecto
y usar el comando:  rosrun turtle_bot_15 turtle_bot_teleop.py
Al correr este nodo, debe ingresar como input la velocidad angular y lineal (ingrese enteros entre 1 y 60)
Luego, la misma consola leerá automáticamente las teclas que esté ingresando el usuario para controlar e turtlebot.




Nodo turtle_bot_interface.py:

IMPORTANTE: Antes de correr este nodo, el nodo teleop.py ya debe estar activo. 
Luego, para correr el nodo turtle_bot_interface.py dirijase al workspace del proyecte y use el comando: 
rosrun turtle_bot_15 turtle_bot_teleop.py
Al correr este nodo se le preguntara si desea guardar el archivo de texto con los comandos ingresados en el teleop.
Para realizar esto digite S como inputs  de lo contrario ingrese n.
Si ingresó S, ahora debe ingresas el nobre del archivo .txt que se va a generar.
IMPORTANTE: El nombre debe ser un string de la forma: nombredelarchivo.txt, es decir, se debe siempre poner el sufijo .txt al final del string. 
Para finalizar este nodo presione ctrl+c y cierre el matlpotlib de la gráfica. 
El archivo .txt quedará guardado automáticamente en la carpeta 'results'.





Nodo turlte_bot_player.py: 

Para correr el nodo turtle_bot_player.py dirijase al workspace del proyecte y use el comando: 
rosrun turtle_bot_15 turtle_bot_player.py

IMPORTANTE: Antes de correr este nodo, debió correr al menos una vez el nodo interface.py y haber generado un archivo .txt,
De lo contrario, no habrá ningún archivo .txt que leer en este nodo. 

Luego, aparecerá un mensaje diciendo 'listo para reproducir secuencia de acciones'. Cuando aparezca este mensaje, debe abrir otra terminal
e ingresas el comando: rosservice call /reproducir_partida nombredelarchivo.txt
Donde nombredelarchivo es el nombre que se le puso al archivo .txt generado en el nodo interface.py
Luego de presionar enter, el nodo funcionará. 


