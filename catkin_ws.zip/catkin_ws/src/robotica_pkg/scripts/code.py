


#!/usr/bin/python3
import serial
import time
from pynput.keyboard import Key, Listener

ser = serial.Serial('/dev/ttyACM0', 9600, timeout=5)
# globals
vel_msg='N'

current_msg = 'N'
#speed = 0
#angular = 0

# define key press event callback
def on_press(key):
    global vel_msg
    global current_msg
    try:
        k = key.char  # single-char keys
    except:
        k = key.name  # other keys
    if (k == "w"):
        vel_msg='W'
        current_msg = "W"
    elif (k == "s"):
        vel_msg='S'
        current_msg = 'S'
    elif (k == "a"):
        vel_msg='A'
        current_msg='A'
        current_msg = "A"
    elif (k == "d"):
        vel_msg='D'
        current_msg = "D"

# define key release event callback
def on_release(key):
    global vel_msg
    global current_msg

    vel_msg='N'

    current_msg = "N"


# read from Arduino

input = ser.read()
print ("Read input " + input.decode("utf-8") + " from Arduino")


while 1:
        # write something back
        # setup keyboard listener
        listener = Listener(on_press=on_press, on_release=on_release, suppress=False)
        listener.start()
        
        ser.write(bytes(str(vel_msg)+'\n', 'utf-8'))
       
        time.sleep(1)


        # read response back from Arduino
        #ser.write(b'set on\n')
        #input_str = ser.readline().decode("utf-8").strip()
        #if (input_str==""):
           # print(".")
        #else:
            #print("Read input back" + input_str)
